<?php
  require_once('config/init.php');
//   $_SESSION['cart']= '0'; 

//   header('Location: ' . $_SERVER['HTTP_REFERER']);
