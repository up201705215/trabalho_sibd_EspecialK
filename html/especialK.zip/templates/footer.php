<footer class="full-width">
  <p>Especial K</p>
  <a href="quemsomos.php">Encontre-nos</a>
  <a href="contatos.php">Quem Somos</a>
  <i class="fab fa-facebook-square"></i>
  <i class="fab fa-instagram"></i>
  <i class="fab fa-twitter"></i>
</footer>
</body>

</html>