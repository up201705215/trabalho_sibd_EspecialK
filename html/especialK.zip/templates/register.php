<section id="register">
  <h2>Register</h2>
  <form action="action_register.php" method="post" enctype="multipart/form-data">
    <label for="username">Username</label>
    <input type="text" name="username" placeholder="username">
    <label for="password">Password</label>
    <input type="password" name="password" placeholder="password">
    <label for="email">Email</label>
    <input type="text" name="email" placeholder="email">
    <label for="morada">Morada</label>
    <input type="text" name="morada" placeholder="morada">

    <input type="file" name="pic" placeholder="pic">
    <input type="submit" value="Submit">

  </form>
</section>