<html>

<head>
  <title> Quem Somos</title>
</head>
<p>
  Somos o Especial K restaurante , um espaco que priveligia a partilha de sabores e de momentos num ambiente confortável e moderno aliado à nova tecnologia. Localizado em plena Rua Dr. Roberto Frias, o ESPECIAL K pretende afirmar-se como uma referencia no que toca a boa comida e alta tecnologia associada nesta zona nobre da cidade. Para além do restaurante, todo o nosso sistema de reservas bem como o pagamento através da simplicidade de um clique, faz do nosso espaco e do nosso atendimento um dos melhores da cidade, tornado-o assim no local ideal para um cocktail e um bom jantar, para relaxar em qualquer momento do seu dia. Faca a sua reserva e deixe tudo por nossa conta
</p>
<img src="images/employees.jpg" alt="employees" class="employees">


</html>