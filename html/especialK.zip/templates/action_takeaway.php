<!DOCTYPE html>
<html>


<body>
    <section id="takeaway">

    <h2>Parabens!!! A sua reserva takeaway no nosso restuarante foi bem sucedida!!!</h2>
    <p>A entrega sera realizada no nosso balcao takeaway a <?php echo $buscar['nome_takeaway']?>. Nao se esqueça, contamos sempre com a sua preferencia!!! Bom apetite!!! </p>
</section>
</body>

</html>