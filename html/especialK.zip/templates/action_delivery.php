<!DOCTYPE html>
<html>


<body>
    <section id="delivery">
     <h2>Parabéns!!! A sua reserva para entrega foi feita com sucesso!!!</h2>
    <p>A entrega será realizada a <?php echo $entrega['nome_delivery']?>  com o contacto <?php echo $entrega['telefone']?> na morada <?php echo $user['morada']?>. Nao se esqueca, contamos sempre com a sua preferência!!! Bom apetite!!! </p>
</section>
</body>



</html>
