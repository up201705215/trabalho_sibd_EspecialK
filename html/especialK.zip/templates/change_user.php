<section id="change_user">
  <h2>Mude a palavra passe</h2>
  <form action="action_change_user.php" method="post" enctype="multipart/form-data">
    <p for="password">antiga</p>
    <input type="password" name="antiga" placeholder="antiga">
    <p for="password">nova</p>
    <input type="password" name="nova" placeholder="nova">
    <p for="password">confirma</p>
    <input type="password" name="confirma" placeholder="confirma">
    <!-- <label for="email">Email</label>
    <input type="text" name="email" placeholder="email">
    <label for="morada">Morada</label>
    <input type="text" name="morada" placeholder="morada"> 

    <input type="file" name="pic" placeholder="pic"> !-->
    <input type="submit" value="Submit">

  </form>
</section>