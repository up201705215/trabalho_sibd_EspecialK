<?php
  require_once('config/init.php');

  include('templates/header.php');
  include('templates/add_product.php');
  include('templates/footer.php');
