<?php
require_once('config/init.php');

include('templates/header.php');
include('templates/cnts.php');
include('templates/footer.php');
